import {DepartmentsComponent} from './departments.component';
import {Router } from '@angular/router';
import {StudentService} from '../student/student.service';
import {NgForm } from '@angular/forms';

describe('DepartmentsComponent' , ()=> {
   let component : DepartmentsComponent; 
   let router : Router;
   let service : StudentService;
   let form : NgForm;
   beforeEach(()=>{
   
       component = new DepartmentsComponent(router , service );
   })

   it("should create Departments component", () => {
    expect(component).toBeTruthy();
  });


});