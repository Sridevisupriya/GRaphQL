import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import{StudentService} from '../student/student.service';
import {Notice} from '../notice/notice.model';
import { Subscription } from 'rxjs';
import { Student } from '../student/student.model';
import {GraphqlService} from '../student/graphql.service';

@Component({
  selector: 'app-branch',
  templateUrl: './departments.component.html',
  styleUrls: ['./departments.component.css']
})
export class DepartmentsComponent implements OnInit {
  currentSelected : string = 'Departments';
  cse : string = "cse";
  ece : string = "ece";
  mech : string = "mech";
  eee : string = "eee";
  Notices : Notice[];
  Students : Student[];
  allUserSubscription : Subscription;
  constructor(private router: Router, private studentService:StudentService , private graphqlService : GraphqlService){}

  ngOnInit(): void {   
    this.graphqlService.getNotices();
    this.studentService.getNotices();
    this.allUserSubscription = this.studentService.allnotices.subscribe((notices) => {
      this.Notices = notices,
      console.log(this.Notices);
     
    });

    this.studentService.getAllStudents();
    this.allUserSubscription = this.studentService.allUsers.subscribe((users) => {
      this.Students = users,
      console.log(this.Students);
     
    });
  }
  calculateDiff(dateSent:any){
    let currentDate = new Date();
    dateSent = new Date(dateSent);
    return Math.floor((Date.UTC(currentDate.getFullYear(), currentDate.getMonth(), currentDate.getDate()) - Date.UTC(dateSent.getFullYear(), dateSent.getMonth(), dateSent.getDate()) ) /(1000 * 60 * 60 * 24));
}
  onTouch(course:string){
    this.router.navigateByUrl('app/home/departments/departmentlists/'+ course);  
  }

  getCount()
  {
    return this.Students.length;
    
  }
  ngOnDestroy(): void {
   
}

}