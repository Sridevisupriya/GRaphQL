import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import {Notice} from './notice.model';
import {StudentService} from '../student/student.service';

@Component({
  selector: 'app-notice',
  templateUrl: './notice.component.html',
  styleUrls: ['./notice.component.css']
})
export class NoticeComponent implements OnInit {
  currentSelected : string = 'notice';
  errorMessage = '';
  successfullMessage='';
  notice='';
  
  constructor(private studentService: StudentService , private router: Router) { }

  ngOnInit(): void {
  } 

  onAddNotice(form: NgForm){
    if(!form.valid){
      this.errorMessage = "Please fill all the fields!";
      return;
    }
    
    const notice = new Notice(
      this.notice , new Date('11/11/2001'));
      
      this.studentService.addNotice(notice).subscribe((responseData) => {
        this.successfullMessage = 'Admission Successfull!';
        form.reset();
      },error => {
        this.errorMessage = "Error";
      });
      this.router.navigateByUrl('app/home/departments');
  }
}