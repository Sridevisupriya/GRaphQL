import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {AppRoutingModule} from './app-routing.module';
import {HttpClientModule} from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule ,  ReactiveFormsModule} from '@angular/forms';
import { AppComponent } from './app.component';
import {HomeComponent} from './home/home.component';
import {HeaderComponent} from './header/header.component';
import {DepartmentsComponent} from './departments/departments.component';
import {DepartmentListComponent} from './departments/departmentlists/departmentLists.component';
import {AdmissionComponent} from './admission/admission.component';
import {UpdateStudentComponent} from './student/updatestudent/updatestudent.component';
import {NoticeComponent} from './notice/notice.component';
import {LoginComponent} from './login/login.component';
import { GraphQLModule } from './graphql.module';

@NgModule({
  declarations: [
    AppComponent ,
    HomeComponent,
    HeaderComponent,
    DepartmentsComponent,
    DepartmentListComponent,
    AdmissionComponent,
    UpdateStudentComponent,
    NoticeComponent,
    LoginComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,
    GraphQLModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
 