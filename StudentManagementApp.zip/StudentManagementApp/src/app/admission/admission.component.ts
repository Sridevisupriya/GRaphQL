import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import {Student} from '../student/student.model';
import {StudentService} from '../student/student.service';

@Component({
  selector: 'app-admission',
  templateUrl: './admission.component.html',
  styleUrls: ['./admission.component.css']
})
export class AdmissionComponent implements OnInit {
  currentSelected : string = 'Header';
  errorMessage = '';
  successfullMessage='';
  options = [
    {key: 1, value:"CSE"},
    {key: 2, value:"ECE"},
    {key: 3, value:"MECH"},
    {key: 4, value:"EEE"}
  ]
  constructor(private studentService: StudentService , private router: Router) { }

  ngOnInit(): void {
  }

  onAddStudent(form: NgForm){

    if(!form.valid){
      this.errorMessage = "Please fill all the fields!";
      return;
    }
    
    const student = new Student(
      form.value.email, 
      form.value.name, 
      form.value.gender, 
      form.value.mobile, 
      form.value.course, 
      form.value.dateOfBirth,
      form.value.address)
      this.studentService.addStudent(student).subscribe((responseData) => {
        this.successfullMessage = 'Admission Successfull!';
        form.reset();
      },error => {
        this.errorMessage = "Email already Exists!";
      });
      this.router.navigateByUrl('app/home/departments');
  }
}