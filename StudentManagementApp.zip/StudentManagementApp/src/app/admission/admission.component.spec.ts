import {AdmissionComponent} from './admission.component';
import {  Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { TestBed, async } from '@angular/core/testing';
import {StudentService} from '../student/student.service';
import {NgForm } from '@angular/forms';

describe('AdmissionComponent' , ()=> {
   let component : AdmissionComponent; 
   let router : Router;
   let service : StudentService;
   let form : NgForm;
   beforeEach(()=>{
    TestBed.configureTestingModule({
        imports:[
          RouterTestingModule 
        ]})
       component = new AdmissionComponent(service , router);
   })

   it("should create Admission component", () => {
    expect(component).toBeTruthy();
  });

  it("should -----------", () =>{
    
    component.onAddStudent(form);
    expect(component.onAddStudent(form)).toBeFalsy();

  });

   

 
});