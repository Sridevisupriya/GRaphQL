import { NgModule } from '@angular/core';
import { HomeComponent } from './home/home.component';
import { RouterModule, Routes } from '@angular/router';
import { DepartmentsComponent } from './departments/departments.component';
import {DepartmentListComponent} from './departments/departmentlists/departmentLists.component';
import {AdmissionComponent} from './admission/admission.component';
import {UpdateStudentComponent} from './student/updatestudent/updatestudent.component';
import {NoticeComponent} from './notice/notice.component';
import {LoginComponent} from './login/login.component';
const routes: Routes = [
    {path: '', redirectTo: 'app', pathMatch: "full"},    
    {path: 'app/home', component: HomeComponent,children:[
      {path: 'departments',component: DepartmentsComponent},
      {path: 'admission',component : AdmissionComponent },
      {path: 'departments/departmentlists/:course', component: DepartmentListComponent},
      {path: 'student/updatestudent/:email', component: UpdateStudentComponent},
      {path: 'notice',component : NoticeComponent }
    ]},     
     {path:'app',component:LoginComponent}
  ];
  
  @NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
  })
  export class AppRoutingModule { }