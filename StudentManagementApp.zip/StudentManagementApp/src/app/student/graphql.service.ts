import { Injectable } from '@angular/core';
import { Apollo } from 'apollo-angular';
import {APOLLO_OPTIONS} from 'apollo-angular';
import {ApolloClientOptions , InMemoryCache} from '@apollo/client';
import {HttpLink} from 'apollo-angular/http';
import gql from 'graphql-tag';
import { Student } from './student.model';
import {Notice} from '../notice/notice.model';

@Injectable({
  providedIn: 'root'
})
export class GraphqlService {
  public students: Student[];
  public notices : Notice[]

  constructor(private apollo: Apollo, httpLink: HttpLink) {
    apollo.create({
      link: httpLink.create({ uri: 'https://localhost:44352/graphql'}),
      cache: new InMemoryCache()
    })
  }

  public getNotices = () => {
    this.apollo.query({
      query: gql`query GetAllNotices{  
        notices{
         id
         noticeData
         date
        }
      }`
    }).subscribe(result => {
      this.notices = result.data as Notice[];
    console.log(this.notices);
    })
  }

}