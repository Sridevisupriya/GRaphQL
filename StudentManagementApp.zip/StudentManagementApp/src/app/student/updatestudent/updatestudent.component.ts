import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import {StudentService} from '../../student/student.service';
import { Student } from 'src/app/student/student.model';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-updatestudent',
  templateUrl: './updatestudent.component.html',
  styleUrls: ['./updatestudent.component.css']
})
export class UpdateStudentComponent implements OnInit {
  currentSelected : string = 'UpdateStudent';
  user: Student;
  isAccountUpdateSuccessfull=false;
  UserSubscription : Subscription;
  name:string;
  gender:string;
  mobile:string;
  address:string;
  dob:Date;
  constructor(private route: ActivatedRoute,private router: Router , private studentService:StudentService){}

  ngOnInit(): void { 
    this.route.params.subscribe((param) => {
      this.studentService.getStudentByEmail(param['email']);
    });

    this.UserSubscription =  this.studentService.userDetail.subscribe((userDetail) =>{
      this.user = userDetail
    });
    console.log(this.user);
    
  }
  onSubmit(form : NgForm){
    if(!form.valid){
      return;
    }
    const userDetail = new Student(
      this.user.email,
      form.value.name,
      form.value.gender,
      form.value.mobile,
      this.user.course,
      form.value.dob,
      form.value.address
      );
     
      this.studentService.updateStudent(this.user.email, userDetail).subscribe((res) =>{
        if(res){
          this.isAccountUpdateSuccessfull = true;  
          this.router.navigateByUrl('app/home/departments/departmentlists/'+ this.user.course);
      }});    
  }

}