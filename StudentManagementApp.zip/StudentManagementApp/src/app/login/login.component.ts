import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  currentSelected : string = 'Login';
  name:'';
  password:'';
  constructor(private router : Router) { }

  ngOnInit(): void {
  }

  onSubmit(form : NgForm){
    if(!form.valid){
      return;
    }
    if(form.value.name=='Admin' && form.value.password =='Admin123')
    {
      this.router.navigateByUrl('app/home/departments');
    }
  }
}