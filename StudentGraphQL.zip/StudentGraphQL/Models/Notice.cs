﻿using System;

namespace StudentGraphQL.Models
{
    public class Notice
    {
        public int Id { get; set; }
        public string NoticeData { get; set; }
        public DateTime date { get; set; }
    }
}
